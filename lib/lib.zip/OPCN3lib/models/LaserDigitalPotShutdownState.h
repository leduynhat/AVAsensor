struct LaserDigitalPotShutdownState
{
    bool laserOn;
    bool valid;
};