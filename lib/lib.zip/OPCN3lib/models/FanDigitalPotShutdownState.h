struct FanDigitalPotShutdownState
{
    bool fanOn;
    bool valid;
};